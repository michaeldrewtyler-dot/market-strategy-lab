"""
Swing Trade Backtester

Tests swing-trading rules on up to 20 years of real daily prices, the way you
actually trade: risk a set amount per trade, a stop-loss on every position, a
trailing stop to lock in gains, and (optionally) staying out of earnings.
Educational tool, not financial advice.

Setup (one time):
    pip3 install yfinance pandas matplotlib
Run:
    python3 backtester.py

Change the rules in SETTINGS and STRATEGIES below.
Results (report.md, trades.csv, charts) go in a folder called backtest_results.
"""

import os
import time
import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ======================= SETTINGS =======================
# A mix of big winners, average stocks, and real flops, so results aren't
# flattered by only picking stocks we already know went up.
TICKERS = [
    # winners
    "NVDA", "AAPL", "MSFT", "AMZN", "GOOGL", "META", "AVGO", "AMD", "TSM", "MU",
    "COST", "MA", "V", "LLY", "NFLX", "PLTR",
    # middle of the road
    "JPM", "RTX", "KO", "PG", "JNJ", "XOM", "CAT", "HD", "WMT", "CSCO", "ORCL", "IBM", "GS",
    # laggards and flops
    "INTC", "PYPL", "DIS", "NKE", "BA", "WBA", "PFE", "VZ", "T", "F", "SBUX", "MMM",
    "CVS", "BABA", "SNAP", "ZM", "PTON", "C", "AIG",
]
BENCHMARK = "SPY"
YEARS = 20                 # 20 years reaches back through the 2008 crash

START_CAPITAL = 10_000
RISK_MODE = "percent"      # "percent" = risk a % of the account (grows with it)
                           # "dollars" = risk a flat $ amount every trade
RISK_PCT = 0.01            # 1% of the account per trade (percent mode)
RISK_PER_TRADE = 100       # flat $ per trade (dollars mode)
MAX_POSITIONS = 5          # most trades open at once
MAX_POSITION_PCT = 0.25    # no single position bigger than 25% of the account
SLIPPAGE = 0.0005          # 0.05% worse fill on every buy and sell

# ---- earnings filter ----
USE_EARNINGS_FILTER = True
EARNINGS_BUFFER_DAYS = 5   # don't open a trade if earnings are within this many days
EXIT_BEFORE_EARNINGS = True  # close open trades right before an earnings report

# ======================= STRATEGIES =======================
# Each setup below gets backtested and shown side by side.
#   entry: "pullback" and/or "breakout"
#   stop:  "swing" = below the most recent higher low   |  "atr" = X ATRs below entry
#   trail: "swing" = stop moves up to each new higher low |  "atr" = X ATRs below highest close
#   max_hold: trading days before forced exit (None = no limit)
#   exit_below_sma50: also exit if price closes below the 50-day average

MY_RULES = dict(
    name="Your rules",
    entry=["pullback", "breakout"],
    stop="swing",            # below the recent higher low
    trail="swing",           # exit when structure breaks (a lower low)
    max_hold=None,           # no time limit, the trend decides
    exit_below_sma50=True,   # bigger trend break = sell signal
)
LAST_TEST = dict(
    name="Last test rules",
    entry=["pullback"], stop="atr", trail="atr", max_hold=30, exit_below_sma50=True,
)
RUN = [MY_RULES, LAST_TEST]

SWING_BARS = 3             # a swing low needs this many higher bars on each side
SWING_BUFFER_ATR = 0.2     # put the stop this far (in ATRs) under the swing low
MIN_STOP_ATR = 0.5         # stops closer than this get widened (avoid noise stop-outs)
MAX_STOP_ATR = 4.0         # skip trades whose swing low is farther than this (too loose)
STOP_ATR = 2.0             # "atr" stop distance
TRAIL_ATR = 3.0            # "atr" trailing distance
# ==========================================================

OUT_DIR = "backtest_results"
EARNINGS_CACHE = "earnings_cache.csv"


# ---------------- indicators ----------------
def add_indicators(df):
    df = df.copy()
    df["SMA50"] = df["Close"].rolling(50).mean()
    df["SMA200"] = df["Close"].rolling(200).mean()
    df["EMA20"] = df["Close"].ewm(span=20, adjust=False).mean()
    prev_close = df["Close"].shift(1)
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - prev_close).abs(),
                    (df["Low"] - prev_close).abs()], axis=1).max(axis=1)
    df["ATR"] = tr.ewm(alpha=1 / 14, adjust=False).mean()      # 14-day ATR (Wilder)
    df["VolAvg20"] = df["Volume"].rolling(20).mean()
    df["High20"] = df["High"].rolling(20).max().shift(1)       # prior 20-day high
    # swing points: only "known" SWING_BARS days after they happen (no peeking)
    w = 2 * SWING_BARS + 1
    is_low = df["Low"] == df["Low"].rolling(w, center=True).min()
    is_high = df["High"] == df["High"].rolling(w, center=True).max()
    df["SwingLow"] = df["Low"].where(is_low).shift(SWING_BARS).ffill()
    df["SwingHigh"] = df["High"].where(is_high).shift(SWING_BARS).ffill()
    return df


# ---------------- entry rules ----------------
# Each rule uses ONLY data up to that day's close and returns True/False for every
# day. The backtester buys at the NEXT day's open, so there's no peeking ahead.

def pullback_signal(df):
    """Uptrend + dip to the 20 EMA + bounce above yesterday's high."""
    uptrend = (df["Close"] > df["SMA50"]) & (df["SMA50"] > df["SMA200"])
    dipped = (df["Low"] <= df["EMA20"] * 1.01).astype(int).rolling(4).max() == 1
    bounce = (df["Close"] > df["EMA20"]) & (df["Close"] > df["High"].shift(1))
    return uptrend & dipped & bounce


def breakout_signal(df):
    """Closes through resistance (the last swing high) on above-average volume, in an uptrend."""
    res = df["SwingHigh"]
    fresh = (df["Close"] > res) & (df["Close"].shift(1) <= res.shift(1))
    return fresh & (df["Volume"] > 1.3 * df["VolAvg20"]) & (df["Close"] > df["SMA50"])


SIGNALS = {"pullback": pullback_signal, "breakout": breakout_signal}


# ---------------- data ----------------
def download(tickers):
    start = (pd.Timestamp.today() - pd.DateOffset(years=YEARS)).strftime("%Y-%m-%d")
    print(f"Downloading daily prices since {start} for {len(tickers)} tickers...")
    raw = yf.download(tickers, start=start, auto_adjust=True, progress=False, group_by="ticker")
    out = {}
    for t in tickers:
        try:
            df = raw[t] if isinstance(raw.columns, pd.MultiIndex) else raw
            df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
            df = df[(df["Close"] > 0) & (df["Open"] > 0)]
            if len(df) > 250:
                out[t] = add_indicators(df)
            else:
                print(f"  Skipping {t}: not enough history.")
        except Exception:
            print(f"  Skipping {t}: no data.")
    return out


def load_earnings(tickers):
    """Earnings dates per ticker (cached in a file so it only downloads once)."""
    cache = {}
    if os.path.exists(EARNINGS_CACHE):
        c = pd.read_csv(EARNINGS_CACHE)
        for t, g in c.groupby("ticker"):
            cache[t] = sorted(pd.to_datetime(g["date"].dropna()).tolist())
    need = [t for t in tickers if t not in cache]
    if need:
        print(f"Downloading earnings dates for {len(need)} tickers (one time)...")
    rows = []
    for t in need:
        dates = []
        try:
            ed = yf.Ticker(t).get_earnings_dates(limit=100)
            if ed is not None and len(ed):
                idx = pd.DatetimeIndex(ed.index)
                if idx.tz is not None:
                    idx = idx.tz_localize(None)            # keep New York calendar date
                dates = sorted(set(idx.normalize()))
        except Exception:
            pass
        cache[t] = dates
        rows += [{"ticker": t, "date": d.date()} for d in dates] or [{"ticker": t, "date": None}]
        time.sleep(0.3)                                    # be polite to Yahoo
    if rows:
        new = pd.DataFrame(rows)
        if os.path.exists(EARNINGS_CACHE):
            new = pd.concat([pd.read_csv(EARNINGS_CACHE), new])
        new.to_csv(EARNINGS_CACHE, index=False)
    got = [t for t in tickers if cache.get(t)]
    if got:
        earliest = min(cache[t][0] for t in got)
        print(f"  Earnings dates for {len(got)}/{len(tickers)} tickers, back to {earliest.year}. "
              f"(Earlier years can't be filtered.)")
    else:
        print("  Couldn't get any earnings dates, so the earnings filter is off.")
    return {t: np.array(cache.get(t, []), dtype="datetime64[ns]") for t in tickers}


def earnings_between(earn, t, start, end):
    arr = earn.get(t)
    if arr is None or len(arr) == 0:
        return False
    j = np.searchsorted(arr, np.datetime64(start))
    return j < len(arr) and arr[j] <= np.datetime64(end)


# ---------------- backtest ----------------
def run(data, cfg, earn):
    dates = pd.DatetimeIndex(sorted(set().union(*[set(df.index) for df in data.values()])))
    closes = pd.DataFrame({t: df["Close"] for t, df in data.items()}).reindex(dates).ffill()
    def combined(df):
        out = pd.Series(False, index=df.index)
        for e in cfg["entry"]:
            out |= SIGNALS[e](df).fillna(False).astype(bool)
        return out
    sigs = pd.DataFrame({t: combined(df) for t, df in data.items()}).reindex(dates)
    sigs = sigs.fillna(False).astype(bool)
    ready = pd.DataFrame({t: df["SMA200"].notna() for t, df in data.items()}).reindex(dates)
    sigs &= ready.fillna(False).astype(bool)
    rng = np.random.default_rng(0)

    cash, positions, pending = START_CAPITAL, {}, []
    trades, equity, invested = [], [], []

    def close_trade(t, p, d, px, reason):
        nonlocal cash
        px *= (1 - SLIPPAGE)
        pnl = (px - p["entry"]) * p["shares"]
        cash += px * p["shares"]
        trades.append(dict(ticker=t, entry_date=p["date"].date(), exit_date=d.date(),
                           entry=round(p["entry"], 2), exit=round(px, 2), shares=p["shares"],
                           pnl=round(pnl, 2), R=round(pnl / p["risk"], 2), days=p["days"],
                           reason=reason))

    for k, d in enumerate(dates):
        next_d = dates[k + 1] if k + 1 < len(dates) else d + pd.Timedelta(days=1)

        # 1) fill yesterday's signals at today's open (random order when too many)
        rng.shuffle(pending)
        for t, atr, swing in pending:
            df = data[t]
            if d not in df.index or t in positions or len(positions) >= MAX_POSITIONS:
                continue
            entry = df.at[d, "Open"] * (1 + SLIPPAGE)
            if cfg["stop"] == "swing":
                if pd.isna(swing):
                    continue
                stop = swing - SWING_BUFFER_ATR * atr
                if entry - stop > MAX_STOP_ATR * atr:
                    continue                                    # swing low too far away
                stop = min(stop, entry - MIN_STOP_ATR * atr)    # not uselessly tight
            else:
                stop = entry - STOP_ATR * atr
            per_share = entry - stop
            if per_share <= 0:
                continue
            acct = cash + sum(p["shares"] * closes.at[d, pt] for pt, p in positions.items())
            risk_budget = acct * RISK_PCT if RISK_MODE == "percent" else RISK_PER_TRADE
            shares = min(int(risk_budget // per_share), int(acct * MAX_POSITION_PCT // entry),
                         int(cash // entry))
            if shares < 1:
                continue
            cash -= shares * entry
            positions[t] = dict(entry=entry, stop=stop, shares=shares, date=d, days=0,
                                high_close=entry, risk=per_share * shares)
        pending = []

        # 2) manage open positions with today's bar
        for t in list(positions):
            df, p = data[t], positions[t]
            if d not in df.index:
                continue
            o, lo, c = df.at[d, "Open"], df.at[d, "Low"], df.at[d, "Close"]
            p["days"] += 1
            if o <= p["stop"]:
                close_trade(t, p, d, o, "stop (gap)")
            elif lo <= p["stop"]:
                close_trade(t, p, d, p["stop"], "stop" if p["stop"] < p["entry"] else "trailing stop")
            elif cfg["exit_below_sma50"] and c < df.at[d, "SMA50"]:
                close_trade(t, p, d, c, "below 50-day")
            elif cfg["max_hold"] and p["days"] >= cfg["max_hold"]:
                close_trade(t, p, d, c, "time limit")
            elif (USE_EARNINGS_FILTER and EXIT_BEFORE_EARNINGS
                  and earnings_between(earn, t, d, next_d)):
                close_trade(t, p, d, c, "before earnings")
            else:
                p["high_close"] = max(p["high_close"], c)             # trail the stop up
                if cfg["trail"] == "swing":
                    sl = df.at[d, "SwingLow"]
                    if not pd.isna(sl):
                        p["stop"] = max(p["stop"], sl - SWING_BUFFER_ATR * df.at[d, "ATR"])
                else:
                    p["stop"] = max(p["stop"], p["high_close"] - TRAIL_ATR * df.at[d, "ATR"])
                continue
            del positions[t]

        # 3) new signals at today's close (fill tomorrow)
        for t in sigs.columns[sigs.loc[d].values]:
            if t in positions:
                continue
            if USE_EARNINGS_FILTER and earnings_between(
                    earn, t, d, d + pd.Timedelta(days=EARNINGS_BUFFER_DAYS)):
                continue
            pending.append((t, data[t].at[d, "ATR"], data[t].at[d, "SwingLow"]))

        # 4) mark to market
        held = sum(p["shares"] * closes.at[d, t] for t, p in positions.items())
        equity.append(cash + held)
        invested.append(held / (cash + held) if cash + held > 0 else 0)

    for t, p in positions.items():                    # close leftovers at the last price
        close_trade(t, p, dates[-1], closes[t].iloc[-1], "still open")
    return pd.DataFrame(trades), pd.Series(equity, index=dates), float(np.mean(invested))


# ---------------- report ----------------
def cagr_of(s):
    years = (s.index[-1] - s.index[0]).days / 365.25
    return (s.iloc[-1] / s.iloc[0]) ** (1 / years) - 1 if years > 0 else float("nan")


def yearly(s):
    ends = s.groupby(s.index.year).last()
    starts = ends.shift(1)
    starts.iloc[0] = s.iloc[0]
    return ends / starts - 1


def summarize(trades, eq, bench, exposure):
    cagr, b_cagr = cagr_of(eq), cagr_of(bench)
    dd = (eq / eq.cummax() - 1).min()
    s = {"Final account": f"${eq.iloc[-1]:,.0f}",
         "Yearly return (CAGR)": f"{cagr:+.1%}",
         "Worst drawdown": f"{dd:.1%}",
         "Return per unit of drawdown": f"{cagr / abs(dd):.2f}",
         "Time invested": f"{exposure:.0%}",
         "Trades": f"{len(trades)}"}
    exp = float("nan")
    if len(trades):
        wins, losses = trades[trades.pnl > 0], trades[trades.pnl <= 0]
        gl = -losses.pnl.sum()
        exp = trades.R.mean()
        s.update({"Win rate": f"{len(wins) / len(trades):.0%}",
                  "Average win": f"{wins.R.mean():+.2f}R" if len(wins) else "n/a",
                  "Average loss": f"{losses.R.mean():+.2f}R" if len(losses) else "n/a",
                  "Expectancy per trade": f"{exp:+.2f}R",
                  "Profit factor": f"{wins.pnl.sum() / gl:.2f}" if gl > 0 else "inf",
                  "Average hold": f"{trades.days.mean():.0f} days",
                  "Biggest loss": f"{trades.R.min():+.2f}R"})
    yr = yearly(eq)
    s["Years beating the S&P"] = f"{int((yr > yearly(bench)).sum())} of {len(yr)}"
    return s, cagr, exp


def verdict(n, exp, cagr, b_cagr):
    if n < 30:
        return "too few trades to trust"
    if exp <= 0:
        return "no edge: loses money per trade"
    if cagr < b_cagr:
        return "real edge per trade, but trails just holding the S&P 500"
    return "real edge AND beat the S&P 500 over the whole period"


def main():
    data = download(TICKERS + [BENCHMARK])
    if BENCHMARK not in data:
        raise SystemExit(f"Couldn't get {BENCHMARK} data.")
    bench_full = data.pop(BENCHMARK)["Close"]
    if not data:
        raise SystemExit("No usable ticker data.")
    earn = load_earnings(list(data)) if USE_EARNINGS_FILTER else {}
    risk_txt = f"{RISK_PCT:.1%} of account" if RISK_MODE == "percent" else f"${RISK_PER_TRADE}"

    results = {}
    for cfg in RUN:
        print(f"Backtesting '{cfg['name']}' on {len(data)} stocks, risking {risk_txt} per trade...")
        trades, eq, exposure = run(data, cfg, earn)
        bench = bench_full.reindex(eq.index).ffill().dropna()
        eq = eq.loc[bench.index]
        s, cagr, exp = summarize(trades, eq, bench, exposure)
        results[cfg["name"]] = dict(trades=trades, eq=eq, s=s, cagr=cagr, exp=exp)

    bench = bench_full.reindex(next(iter(results.values()))["eq"].index).ffill().dropna()
    b_cagr = cagr_of(bench)
    b_dd = (bench / bench.cummax() - 1).min()
    names = list(results)

    # ---- side-by-side table ----
    table = pd.DataFrame({n: results[n]["s"] for n in names})
    table["S&P 500"] = ""
    table.loc["Final account", "S&P 500"] = f"${bench.iloc[-1] / bench.iloc[0] * START_CAPITAL:,.0f}"
    table.loc["Yearly return (CAGR)", "S&P 500"] = f"{b_cagr:+.1%}"
    table.loc["Worst drawdown", "S&P 500"] = f"{b_dd:.1%}"
    table.loc["Return per unit of drawdown", "S&P 500"] = f"{b_cagr / abs(b_dd):.2f}"
    table.loc["Time invested", "S&P 500"] = "100%"
    verdicts = {n: verdict(len(results[n]["trades"]), results[n]["exp"], results[n]["cagr"], b_cagr)
                for n in names}

    yr = pd.DataFrame({n: yearly(results[n]["eq"]) for n in names})
    yr["S&P 500"] = yearly(bench)

    os.makedirs(OUT_DIR, exist_ok=True)
    for n in names:
        fn = "trades_" + n.lower().replace(" ", "_") + ".csv"
        results[n]["trades"].to_csv(os.path.join(OUT_DIR, fn), index=False)
    curve = pd.DataFrame({n: results[n]["eq"] for n in names})
    curve["S&P 500 buy & hold"] = bench / bench.iloc[0] * START_CAPITAL
    ax = curve.plot(figsize=(10, 4.8), logy=True, title="Account value (log scale)")
    ax.set_ylabel("$")
    ax.grid(alpha=0.3, which="both")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "equity.png"), dpi=130)
    plt.close()
    ax = (yr * 100).plot.bar(figsize=(11, 4), title="Return by year (%)")
    ax.axhline(0, color="black", lw=0.8)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "yearly.png"), dpi=130)
    plt.close()

    first = results[names[0]]
    lines = [f"# Backtest: {' vs '.join(names)}",
             f"_{first['eq'].index[0].date()} to {first['eq'].index[-1].date()}, "
             f"${START_CAPITAL:,} start, risking {risk_txt} per trade, earnings filter "
             f"{'on' if USE_EARNINGS_FILTER else 'off'}. Educational, not financial advice._", ""]
    lines += [f"- **{n}:** {v}" for n, v in verdicts.items()]
    lines += ["", "| | " + " | ".join(table.columns) + " |", "|---" * (len(table.columns) + 1) + "|"]
    lines += [f"| {k} | " + " | ".join(str(x) for x in r.values) + " |" for k, r in table.iterrows()]
    lines += ["", "## By year", "| Year | " + " | ".join(yr.columns) + " |",
              "|---" * (len(yr.columns) + 1) + "|"]
    lines += [f"| {y} | " + " | ".join(f"{x:+.1%}" for x in r.values) + " |" for y, r in yr.iterrows()]
    for n in names:
        tr = results[n]["trades"]
        if len(tr):
            lines += ["", f"## Exit reasons: {n}", "| Reason | Trades | Avg R |", "|---|---|---|"]
            lines += [f"| {reason} | {len(g)} | {g.R.mean():+.2f} |" for reason, g in tr.groupby("reason")]
    lines += ["", "![Equity](equity.png)", "![Yearly](yearly.png)", "",
              "_Caveats: only companies that still exist today, no taxes, and past results "
              "don't predict future ones._"]
    with open(os.path.join(OUT_DIR, "report.md"), "w") as f:
        f.write("\n".join(lines))

    print()
    w = max(len(n) for n in table.columns) + 2
    print(" " * 30 + "".join(f"{c:>{w}}" for c in table.columns))
    for k, r in table.iterrows():
        print(f"  {k:28}" + "".join(f"{str(x):>{w}}" for x in r.values))
    print("\n  Year" + "".join(f"{c:>{w}}" for c in yr.columns))
    for y, r in yr.iterrows():
        print(f"  {y}" + "".join(f"{x:>+{w}.1%}" for x in r.values))
    print()
    for n, v in verdicts.items():
        print(f"  {n}: {v}")
    print(f"\nFull report, every trade, and charts: {os.path.abspath(OUT_DIR)}")


if __name__ == "__main__":
    main()
