"""
Portfolio Analyzer - Phase 1

Pulls real price history for a portfolio, measures return and risk the way a
wealth manager would, compares it to the S&P 500, draws charts, and writes a
plain-English summary. Educational tool, not financial advice.

Setup (one time):
    pip3 install yfinance pandas matplotlib
Run:
    python3 portfolio_analyzer.py              -> uses HOLDINGS below
    python3 portfolio_analyzer.py my.csv       -> CSV with columns: ticker,shares

Output goes in a folder called portfolio_report (report.md + charts).
"""

import os
import sys
import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------- settings ----------
HOLDINGS = {            # ticker: number of shares
    "AAPL": 10,
    "MSFT": 5,
    "NVDA": 8,
    "VOO": 4,
}
BENCHMARK = "SPY"       # what to compare against (S&P 500)
YEARS = 3               # how much history to analyze
RISK_FREE = 0.04        # yearly "safe" return (roughly T-bill rate) for the Sharpe ratio
FETCH_SECTORS = True    # look up each holding's sector (slower)
OUT_DIR = "portfolio_report"
# ------------------------------

TRADING_DAYS = 252


def load_holdings():
    if len(sys.argv) > 1:
        path = sys.argv[1].strip()
        df = pd.read_csv(path)
        df.columns = [c.strip().lower() for c in df.columns]
        if not {"ticker", "shares"} <= set(df.columns):
            sys.exit("CSV needs two columns named: ticker,shares")
        out = {}
        for t, s in zip(df["ticker"], df["shares"]):
            t = str(t).strip().upper()
            if t and float(s) > 0:
                out[t] = out.get(t, 0) + float(s)
        return out
    return dict(HOLDINGS)


def get_prices(tickers):
    """Daily adjusted closing prices (splits and dividends included)."""
    data = yf.download(tickers, period=f"{YEARS}y", auto_adjust=True,
                       progress=False, group_by="column")
    if data is None or data.empty:
        sys.exit("Couldn't download prices. Check your internet connection and tickers.")
    close = data["Close"]
    if isinstance(close, pd.Series):
        close = close.to_frame(tickers[0])
    close = close.dropna(how="all")
    missing = [t for t in tickers if t not in close.columns or close[t].dropna().empty]
    return close, missing


def get_sector(ticker):
    try:
        info = yf.Ticker(ticker).info
        if info.get("quoteType") in ("ETF", "MUTUALFUND"):
            return "Fund / ETF"
        return info.get("sector") or "Unknown"
    except Exception:
        return "Unknown"


def cagr(series):
    years = (series.index[-1] - series.index[0]).days / 365.25
    if years <= 0 or series.iloc[0] <= 0:
        return float("nan")
    return (series.iloc[-1] / series.iloc[0]) ** (1 / years) - 1


def one_year_return(series):
    start = series.index[-1] - pd.Timedelta(days=365)
    if series.index[0] > start:
        return float("nan")
    return series.iloc[-1] / series.asof(start) - 1


def max_drawdown(series):
    dd = series / series.cummax() - 1
    return dd.min(), dd


def pct(x):
    return "n/a" if pd.isna(x) else f"{x * 100:+.1f}%"


def money(x):
    return f"${x:,.0f}"


def main():
    holdings = load_holdings()
    if not holdings:
        sys.exit("No holdings found.")
    tickers = list(holdings)
    print(f"Downloading {YEARS} years of prices for {', '.join(tickers)} + {BENCHMARK}...")

    close, missing = get_prices(tickers + [BENCHMARK])
    if BENCHMARK in missing:
        sys.exit(f"Couldn't get prices for the benchmark {BENCHMARK}.")
    for t in missing:
        print(f"  Skipping {t}: no price data (check the ticker).")
        holdings.pop(t, None)
    tickers = list(holdings)
    if not tickers:
        sys.exit("None of the tickers had price data.")

    prices = close[tickers].dropna()                      # days where every holding traded
    bench = close[BENCHMARK].reindex(prices.index).ffill()
    if len(prices) < 60:
        sys.exit("Not enough shared price history to analyze (need ~3 months).")
    if prices.index[0] > close.index[0] + pd.Timedelta(days=30):
        print(f"  Note: history starts {prices.index[0].date()} because one holding is newer.")

    shares = pd.Series(holdings)
    last = prices.iloc[-1]
    values = last * shares
    total = values.sum()
    weights = (values / total).sort_values(ascending=False)

    # the portfolio as if you'd held today's shares the whole time
    port = (prices * shares).sum(axis=1)
    rets = port.pct_change().dropna()
    brets = bench.pct_change().dropna()
    rets, brets = rets.align(brets, join="inner")

    p_cagr, b_cagr = cagr(port), cagr(bench)
    p_1y, b_1y = one_year_return(port), one_year_return(bench)
    p_vol = rets.std() * np.sqrt(TRADING_DAYS)
    b_vol = brets.std() * np.sqrt(TRADING_DAYS)
    p_sharpe = (rets.mean() * TRADING_DAYS - RISK_FREE) / p_vol if p_vol > 0 else float("nan")
    b_sharpe = (brets.mean() * TRADING_DAYS - RISK_FREE) / b_vol if b_vol > 0 else float("nan")
    p_mdd, p_dd = max_drawdown(port)
    b_mdd, b_dd = max_drawdown(bench)
    beta = np.cov(rets, brets)[0, 1] / brets.var() if brets.var() > 0 else float("nan")

    # per holding
    daily = prices.pct_change().dropna()
    rows = []
    for t in weights.index:
        rows.append({
            "Ticker": t,
            "Shares": holdings[t],
            "Price": last[t],
            "Value": values[t],
            "Weight": weights[t],
            "1y return": one_year_return(prices[t]),
            "Volatility": daily[t].std() * np.sqrt(TRADING_DAYS),
        })
    table = pd.DataFrame(rows)

    # most similar pair (moves together = less diversification)
    top_pair, top_corr = None, None
    if len(tickers) > 1:
        corr = daily.corr()
        best = -2
        for i, a in enumerate(tickers):
            for b in tickers[i + 1:]:
                if corr.loc[a, b] > best:
                    best, top_pair = corr.loc[a, b], (a, b)
        top_corr = best

    sectors = {}
    if FETCH_SECTORS:
        print("Looking up sectors...")
        for t in tickers:
            s = get_sector(t)
            sectors[s] = sectors.get(s, 0) + weights[t]

    # ---------- plain-English takeaways ----------
    notes = []
    top_t, top_w = weights.index[0], weights.iloc[0]
    if top_w > 0.25:
        notes.append(f"**Concentrated:** {top_t} is {top_w:.0%} of the portfolio. "
                     f"A bad stretch for that one stock would hit the whole portfolio hard.")
    if len(tickers) > 3 and weights.iloc[:3].sum() > 0.6:
        notes.append(f"Your top 3 holdings make up {weights.iloc[:3].sum():.0%} of the value.")
    if len(tickers) < 5:
        notes.append(f"Only {len(tickers)} holdings. Most diversification benefit comes "
                     f"from owning 15+ stocks or a broad index fund.")
    if not pd.isna(p_cagr) and not pd.isna(b_cagr):
        diff = p_cagr - b_cagr
        verb = "beat" if diff > 0 else "trailed"
        notes.append(f"**Performance:** over this period the portfolio {verb} the S&P 500 "
                     f"by {abs(diff) * 100:.1f} points per year ({pct(p_cagr)} vs {pct(b_cagr)}).")
    if not pd.isna(beta):
        if beta > 1.2:
            notes.append(f"**Risk:** beta is {beta:.2f}, so it tends to swing about "
                         f"{beta:.1f}x as much as the market, up and down.")
        elif beta < 0.8:
            notes.append(f"**Risk:** beta is {beta:.2f}, so it's calmer than the market.")
        else:
            notes.append(f"**Risk:** beta is {beta:.2f}, close to the market's own swings.")
    if p_mdd < -0.30:
        notes.append(f"Its worst drop was {pct(p_mdd)} from a peak. Worth asking whether "
                     f"you'd have held on through that.")
    if not pd.isna(p_sharpe) and not pd.isna(b_sharpe):
        better = "more" if p_sharpe > b_sharpe else "less"
        notes.append(f"**Sharpe ratio** {p_sharpe:.2f} vs the market's {b_sharpe:.2f}: "
                     f"you got {better} return for each unit of risk than just owning the index.")
    if top_pair and top_corr > 0.8:
        notes.append(f"{top_pair[0]} and {top_pair[1]} move together a lot "
                     f"(correlation {top_corr:.2f}), so they don't diversify each other much.")
    big_sector = max(sectors.items(), key=lambda kv: kv[1]) if sectors else None
    if big_sector and big_sector[0] not in ("Fund / ETF", "Unknown") and big_sector[1] > 0.4:
        notes.append(f"{big_sector[1]:.0%} is in one sector ({big_sector[0]}).")

    # ---------- charts ----------
    os.makedirs(OUT_DIR, exist_ok=True)
    growth = pd.DataFrame({
        "Your portfolio": port / port.iloc[0] * 10_000,
        f"S&P 500 ({BENCHMARK})": bench / bench.iloc[0] * 10_000,
    })
    ax = growth.plot(figsize=(9, 4.5), title="Growth of $10,000")
    ax.set_ylabel("Value ($)")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "growth.png"), dpi=130)
    plt.close()

    ax = pd.DataFrame({"Your portfolio": p_dd * 100, f"S&P 500 ({BENCHMARK})": b_dd * 100}).plot(
        figsize=(9, 3.5), title="Drawdown: % below the previous high")
    ax.set_ylabel("%")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "drawdown.png"), dpi=130)
    plt.close()

    ax = (weights[::-1] * 100).plot.barh(figsize=(7, max(2.5, 0.4 * len(weights))),
                                         title="Allocation (% of portfolio)")
    ax.set_xlabel("%")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "allocation.png"), dpi=130)
    plt.close()

    # ---------- report ----------
    start, end = prices.index[0].date(), prices.index[-1].date()
    lines = [
        "# Portfolio Report",
        f"_{start} to {end}. Educational analysis, not financial advice._",
        "",
        f"**Total value:** {money(total)} across {len(tickers)} holdings",
        "",
        "## Takeaways",
        *[f"- {n}" for n in notes],
        "",
        "## Portfolio vs. S&P 500",
        "| | Portfolio | S&P 500 |",
        "|---|---|---|",
        f"| Yearly return (CAGR) | {pct(p_cagr)} | {pct(b_cagr)} |",
        f"| Last 12 months | {pct(p_1y)} | {pct(b_1y)} |",
        f"| Volatility (yearly) | {p_vol:.1%} | {b_vol:.1%} |",
        f"| Sharpe ratio | {p_sharpe:.2f} | {b_sharpe:.2f} |",
        f"| Worst drop | {pct(p_mdd)} | {pct(b_mdd)} |",
        f"| Beta | {beta:.2f} | 1.00 |",
        "",
        "## Holdings",
        "| Ticker | Shares | Price | Value | Weight | 1y return | Volatility |",
        "|---|---|---|---|---|---|---|",
    ]
    for _, r in table.iterrows():
        lines.append(f"| {r['Ticker']} | {r['Shares']:g} | ${r['Price']:,.2f} | {money(r['Value'])} "
                     f"| {r['Weight']:.1%} | {pct(r['1y return'])} | {r['Volatility']:.0%} |")
    if sectors:
        lines += ["", "## Sectors", "| Sector | Weight |", "|---|---|"]
        for s, w in sorted(sectors.items(), key=lambda kv: -kv[1]):
            lines.append(f"| {s} | {w:.1%} |")
    lines += ["", "## Charts", "![Growth](growth.png)", "![Drawdown](drawdown.png)",
              "![Allocation](allocation.png)", "",
              "_Assumes you held today's share counts for the whole period._"]
    with open(os.path.join(OUT_DIR, "report.md"), "w") as f:
        f.write("\n".join(lines))

    # ---------- print summary ----------
    print()
    print(f"Total value: {money(total)}  |  {start} to {end}")
    print(f"Yearly return {pct(p_cagr)} (S&P {pct(b_cagr)})  |  Volatility {p_vol:.0%}  |  "
          f"Sharpe {p_sharpe:.2f}  |  Worst drop {pct(p_mdd)}  |  Beta {beta:.2f}")
    print()
    for n in notes:
        print(" - " + n.replace("**", ""))
    print(f"\nFull report + charts saved in: {os.path.abspath(OUT_DIR)}")


if __name__ == "__main__":
    main()
