"""
Strategy Lab

Tests well-known, research-backed strategy families on 20 years of data, the
honest way: settings are picked using ONLY the older data (training period),
then judged on the newer data they've never seen (test period). The test
period result is the one that counts. Educational tool, not financial advice.

Setup (one time):
    pip3 install yfinance pandas matplotlib
Run:
    python3 strategy_lab.py

Results (report.md + chart) go in a folder called strategy_lab_results.
"""

import os
import itertools
import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ======================= SETTINGS =======================
STOCKS = [
    "NVDA", "AAPL", "MSFT", "AMZN", "GOOGL", "META", "AVGO", "AMD", "TSM", "MU",
    "COST", "MA", "V", "LLY", "NFLX", "PLTR",
    "JPM", "RTX", "KO", "PG", "JNJ", "XOM", "CAT", "HD", "WMT", "CSCO", "ORCL", "IBM", "GS",
    "INTC", "PYPL", "DIS", "NKE", "BA", "WBA", "PFE", "VZ", "T", "F", "SBUX", "MMM",
    "CVS", "BABA", "SNAP", "ZM", "PTON", "C", "AIG",
]
YEARS = 20
TRAIN_END = "2016-12-31"   # settings are chosen using data up to here; judged on data after
COST = 0.001               # 0.1% cost on every dollar traded (commissions, spread, slippage)
OUT_DIR = "strategy_lab_results"
# ========================================================

ETFS = ["SPY", "EFA", "AGG"]   # US stocks, international stocks, US bonds
# The 9 original S&P sector funds (all exist since 1998, none went bust, none hand-picked):
# materials, energy, financials, industrials, tech, staples, utilities, healthcare, discretionary
SECTORS = ["XLB", "XLE", "XLF", "XLI", "XLK", "XLP", "XLU", "XLV", "XLY"]
CASH = "CASH"                  # earns the 3-month T-bill rate


# ---------------- data ----------------
def load():
    start = (pd.Timestamp.today() - pd.DateOffset(years=YEARS)).strftime("%Y-%m-%d")
    tickers = STOCKS + ETFS + SECTORS + ["^IRX"]
    print(f"Downloading daily prices since {start} for {len(tickers)} tickers...")
    raw = yf.download(tickers, start=start, auto_adjust=True, progress=False, group_by="ticker")
    close = {}
    for t in tickers:
        try:
            s = (raw[t] if isinstance(raw.columns, pd.MultiIndex) else raw)["Close"].dropna()
            if len(s) > 60:
                close[t] = s
        except Exception:
            pass
    for t in ETFS + SECTORS:
        if t not in close:
            raise SystemExit(f"Couldn't download {t}.")
    px = pd.DataFrame(close)
    px = px[px["SPY"].notna()]                        # US trading days only
    if "^IRX" in px:
        tbill = px.pop("^IRX").ffill().fillna(0) / 100  # yearly yield, e.g. 0.045
    else:
        print("  No T-bill data; cash earns 0%.")
        tbill = pd.Series(0.0, index=px.index)
    stocks = [t for t in STOCKS if t in px.columns]
    print(f"  Got {len(stocks)} stocks, {len(SECTORS)} sector funds, {', '.join(ETFS)} + T-bill rate.")
    return px, tbill, stocks


def month_ends(index):
    s = index.to_series()
    return pd.DatetimeIndex(s.groupby(index.to_period("M")).max().values)


# ---------------- strategies ----------------
# Each returns target weights per day (rows = days, columns = assets + CASH),
# decided at that day's close using only data up to that day.

def buy_hold(px, tbill, stocks):
    return pd.DataFrame({"SPY": 1.0}, index=px.index)


def trend_spy(px, tbill, stocks, sma=200):
    """Hold the S&P 500 when it's above its moving average (checked monthly), else T-bills."""
    spy = px["SPY"]
    above = spy > spy.rolling(sma).mean()
    me = month_ends(px.index)
    w = pd.DataFrame(index=me, columns=["SPY", CASH], dtype=float)
    w["SPY"] = above.loc[me].astype(float)
    w[CASH] = 1 - w["SPY"]
    return w.reindex(px.index).ffill().fillna({"SPY": 0.0, CASH: 1.0})


def momentum(px, tbill, stocks, lookback=12, top=10, trend_filter=True, universe="stocks"):
    """Each month, own whatever rose the most over the past N months (skipping the
    most recent month), equal weight. Optional: go to cash when the S&P 500 is
    below its 200-day average. universe = "stocks" or "sectors"."""
    stocks = stocks if universe == "stocks" else [t for t in SECTORS if t in px.columns]
    me = month_ends(px.index)
    monthly = px[stocks].loc[me]
    score = monthly.shift(1) / monthly.shift(1 + lookback) - 1
    spy = px["SPY"]
    risk_on = (spy > spy.rolling(200).mean()).loc[me]
    rows = []
    for d in me:
        s = score.loc[d].dropna()
        s = s[px.loc[d, s.index].notna()]
        w = pd.Series(0.0, index=stocks + [CASH])
        if len(s) >= top and (risk_on.loc[d] or not trend_filter):
            w[s.nlargest(top).index] = 1.0 / top
        else:
            w[CASH] = 1.0
        rows.append(w)
    return pd.DataFrame(rows, index=me).reindex(px.index).ffill().fillna(0.0)


def equal_sectors(px, tbill, stocks):
    """Own all 9 sectors equally, rebalanced monthly (the fair comparison for sector momentum)."""
    me = month_ends(px.index)
    w = pd.DataFrame(1.0 / len(SECTORS), index=me, columns=SECTORS)
    return w.reindex(px.index).ffill().fillna(0.0)


def dual_momentum(px, tbill, stocks, lookback=12):
    """Gary Antonacci's 'Global Equities Momentum': if US stocks beat T-bills over the
    lookback, own whichever of US / international stocks did better; otherwise bonds."""
    me = month_ends(px.index)
    days = 21 * lookback
    ret = px[["SPY", "EFA"]] / px[["SPY", "EFA"]].shift(days) - 1
    cash_ret = (1 + tbill / 252).rolling(days).apply(np.prod, raw=True) - 1
    rows = []
    for d in me:
        w = pd.Series(0.0, index=["SPY", "EFA", "AGG"])
        r = ret.loc[d]
        if r.isna().any() or pd.isna(cash_ret.loc[d]):
            w["SPY"] = 1.0
        elif r["SPY"] > cash_ret.loc[d]:
            w[r.idxmax()] = 1.0
        else:
            w["AGG"] = 1.0
        rows.append(w)
    return pd.DataFrame(rows, index=me).reindex(px.index).ffill().fillna({"SPY": 1.0}).fillna(0.0)


def rsi2_spy(px, tbill, stocks, entry=10, exit_sma=5):
    """Larry Connors' short-term dip buy: in an uptrend (above the 200-day), buy the
    S&P 500 after a sharp 2-day drop (RSI(2) below the entry level); sell once it
    closes above its short moving average. T-bills the rest of the time."""
    c = px["SPY"]
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=1 / 2, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=1 / 2, adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, smax = c.rolling(200).mean(), c.rolling(exit_sma).mean()
    inpos, w = False, []
    for d in px.index:
        if not inpos and c[d] > sma200[d] and rsi[d] < entry:
            inpos = True
        elif inpos and c[d] > smax[d]:
            inpos = False
        w.append(1.0 if inpos else 0.0)
    w = pd.Series(w, index=px.index)
    return pd.DataFrame({"SPY": w, CASH: 1 - w})


STRATEGIES = {
    "Buy & hold S&P 500": (buy_hold, {}),
    "S&P 500 + trend filter": (trend_spy, {"sma": [100, 150, 200]}),
    "Equal-weight sectors": (equal_sectors, {}),
    "Sector momentum": (momentum, {"lookback": [3, 6, 9, 12], "top": [2, 3],
                                   "trend_filter": [False], "universe": ["sectors"]}),
    "Sector momentum + trend filter": (momentum, {"lookback": [3, 6, 9, 12], "top": [2, 3],
                                                  "trend_filter": [True], "universe": ["sectors"]}),
    "Stock momentum (BIASED list)": (momentum, {"lookback": [6, 9, 12], "top": [5, 10],
                                                "trend_filter": [False]}),
    "Stock momentum + filter (BIASED)": (momentum, {"lookback": [6, 9, 12], "top": [5, 10],
                                                    "trend_filter": [True]}),
    "Dual momentum (US/Intl/Bonds)": (dual_momentum, {"lookback": [6, 12]}),
    "RSI(2) dip-buying on S&P 500": (rsi2_spy, {"entry": [5, 10, 15]}),
}


# ---------------- simulation + metrics ----------------
def simulate(weights, px, tbill):
    """Daily returns. Weights set at today's close earn tomorrow's return (no peeking)."""
    rets = px.pct_change()
    rets[CASH] = tbill / 252
    cols = [c for c in weights.columns]
    w = weights.reindex(px.index).ffill().fillna(0.0)[cols]
    r = rets[cols].fillna(0.0)
    gross = (w.shift(1).fillna(0.0) * r).sum(axis=1)
    turnover = w.diff().abs().sum(axis=1).fillna(w.abs().sum(axis=1))
    return gross - turnover.shift(1).fillna(0.0) * COST


def metrics(r, tbill):
    r = r.dropna()
    if len(r) < 60:
        return dict(CAGR=np.nan, Vol=np.nan, Sharpe=np.nan, MaxDD=np.nan, MAR=np.nan)
    growth = (1 + r).cumprod()
    years = len(r) / 252
    cagr = growth.iloc[-1] ** (1 / years) - 1
    vol = r.std() * np.sqrt(252)
    excess = r - (tbill.reindex(r.index).fillna(0) / 252)
    sharpe = excess.mean() * 252 / vol if vol > 0 else np.nan
    mdd = (growth / growth.cummax() - 1).min()
    return dict(CAGR=cagr, Vol=vol, Sharpe=sharpe, MaxDD=mdd,
                MAR=cagr / abs(mdd) if mdd < 0 else np.nan)


def main():
    px, tbill, stocks = load()
    warm = px.index[0] + pd.DateOffset(months=13)         # let 12-month lookbacks fill in
    split = pd.Timestamp(TRAIN_END)
    train_idx = px.index[(px.index >= warm) & (px.index <= split)]
    test_idx = px.index[px.index > split]
    if len(train_idx) < 500 or len(test_idx) < 250:
        raise SystemExit("Not enough data on one side of TRAIN_END.")
    print(f"Training: {train_idx[0].date()} to {train_idx[-1].date()}   "
          f"Test: {test_idx[0].date()} to {test_idx[-1].date()}")

    results, n_tested = [], 0
    for name, (fn, grid) in STRATEGIES.items():
        keys = list(grid)
        combos = [dict(zip(keys, v)) for v in itertools.product(*grid.values())] or [{}]
        print(f"  Testing {name} ({len(combos)} setting{'s' if len(combos) > 1 else ''})...")
        runs = []
        for params in combos:
            r = simulate(fn(px, tbill, stocks, **params), px, tbill)
            runs.append((params, r, metrics(r.loc[train_idx], tbill), metrics(r.loc[test_idx], tbill)))
            n_tested += 1
        best = max(runs, key=lambda x: -np.inf if pd.isna(x[2]["Sharpe"]) else x[2]["Sharpe"])
        test_sharpes = [x[3]["Sharpe"] for x in runs]
        results.append(dict(name=name, params=best[0], r=best[1], train=best[2], test=best[3],
                            full=metrics(best[1].loc[px.index >= warm], tbill),
                            test_sharpe_median=float(np.nanmedian(test_sharpes))))

    bh = next(x for x in results if x["name"] == "Buy & hold S&P 500")
    ranked = sorted(results, key=lambda x: -np.nan_to_num(x["test"]["Sharpe"], nan=-9))

    def fmt(m):
        return (f"{m['CAGR']:+6.1%}  {m['Sharpe']:5.2f}  {m['MaxDD']:6.1%}"
                if not pd.isna(m["CAGR"]) else "   n/a")

    print("\n  Settings were picked on TRAINING data only. TEST = years the strategy never saw.\n")
    print(f"  {'Strategy':32} {'TRAIN  CAGR  Sharpe  WorstDD':30} {'TEST  CAGR  Sharpe  WorstDD':30}")
    for x in ranked:
        print(f"  {x['name']:32} {fmt(x['train']):30} {fmt(x['test']):30}")
    print()
    for x in ranked:
        p = ", ".join(f"{k}={v}" for k, v in x["params"].items()) or "-"
        print(f"  {x['name']:32} settings: {p}")

    # ---- verdict ----
    fair = [x for x in results if "BIASED" not in x["name"]]
    top = max(fair, key=lambda x: np.nan_to_num(x["test"]["Sharpe"], nan=-9))
    beat_ret = [x for x in results if x is not bh and x["test"]["CAGR"] > bh["test"]["CAGR"]]
    beat_risk = [x for x in results if x is not bh and x["test"]["Sharpe"] > bh["test"]["Sharpe"]
                 and x["test"]["MaxDD"] > bh["test"]["MaxDD"]]
    if top is bh:
        lines_v = ["Among the fair (unbiased) strategies, nothing beat plain buy & hold of the "
                   "S&P 500 on a risk-adjusted basis in the test period."]
    else:
        lines_v = [f"Best fair (unbiased) strategy in the test period: {top['name']} "
                   f"(Sharpe {top['test']['Sharpe']:.2f} vs buy & hold {bh['test']['Sharpe']:.2f})."]
    lines_v.append("Beat buy & hold on raw return in the test period: "
                   + (", ".join(x["name"] for x in beat_ret) if beat_ret else "none."))
    lines_v.append("Better Sharpe AND smaller worst drop than buy & hold: "
                   + (", ".join(x["name"] for x in beat_risk) if beat_risk else "none."))
    lines_v.append(f"{n_tested} strategy settings were tried in total. The more you try, the more "
                   f"likely the winner is partly luck, so trust results that hold up in BOTH periods.")
    print("\nVerdict:")
    for v in lines_v:
        print("  - " + v)

    # ---- files ----
    os.makedirs(OUT_DIR, exist_ok=True)
    curves = pd.DataFrame({x["name"]: (1 + x["r"].loc[px.index >= warm]).cumprod() * 10_000
                           for x in ranked})
    ax = curves.plot(figsize=(11, 5.5), logy=True, title="Growth of $10,000 (log scale)")
    ax.axvline(split, color="black", ls="--", lw=1)
    ax.text(split, ax.get_ylim()[1], "  training | test  ", va="top", ha="center", fontsize=9,
            bbox=dict(facecolor="white", edgecolor="none"))
    ax.grid(alpha=0.3, which="both")
    ax.set_ylabel("$")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "growth.png"), dpi=130)
    plt.close()

    md = ["# Strategy Lab", f"_Training {train_idx[0].date()} to {train_idx[-1].date()}, "
          f"test {test_idx[0].date()} to {test_idx[-1].date()}. {COST:.1%} trading cost. "
          f"Educational, not financial advice._", "", "## Verdict"]
    md += [f"- {v}" for v in lines_v]
    md += ["", "## Results (test period = the one that counts)",
           "| Strategy | Settings | Train CAGR | Train Sharpe | Train worst drop | Test CAGR | "
           "Test Sharpe | Test worst drop | Full-period CAGR | Median test Sharpe (all settings) |",
           "|---" * 10 + "|"]
    for x in ranked:
        p = ", ".join(f"{k}={v}" for k, v in x["params"].items()) or "-"
        tr, te, fu = x["train"], x["test"], x["full"]
        md.append(f"| {x['name']} | {p} | {tr['CAGR']:+.1%} | {tr['Sharpe']:.2f} | {tr['MaxDD']:.1%} "
                  f"| {te['CAGR']:+.1%} | {te['Sharpe']:.2f} | {te['MaxDD']:.1%} | {fu['CAGR']:+.1%} "
                  f"| {x['test_sharpe_median']:.2f} |")
    md += ["", "![Growth](growth.png)", "",
           "_Caveats: the 'BIASED' stock strategies use a list picked with hindsight and only "
           "companies that survived, so ignore their numbers. Sector funds have no such bias. No taxes (monthly strategies create short-term gains outside an IRA). "
           "Past results don't predict future ones._"]
    with open(os.path.join(OUT_DIR, "report.md"), "w") as f:
        f.write("\n".join(md))
    print(f"\nFull report + chart: {os.path.abspath(OUT_DIR)}")


if __name__ == "__main__":
    main()
